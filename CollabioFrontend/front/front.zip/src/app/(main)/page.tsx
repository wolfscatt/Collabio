import Home from "./../../pages/Home";

export default function page() {
  return (
    <div className=" bg-fixed bg-cover bg-no-repeat w-full min-h-screen">
      <Home/>
    </div>
  );
}
