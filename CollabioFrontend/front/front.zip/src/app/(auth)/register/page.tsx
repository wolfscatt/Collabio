import React from "react";
import RegInput from "../../../../components/RegInput";
import Link from "next/link";

const Register = () => {
  return (
    <div className="min-h-screen w-full bg-register bg-fixed bg-cover bg-no-repeat flex flex-col items-center justify-center">
      <div className="items-center justify-center">
        <img
          src="images/collabio-logo.png"
          alt="Collabio Logo"
          className="w-[24vw] block mx-auto object-contain"
        />
      </div>
      <div className="bg-specPink-300 border-r-8 border-b-8 border-specPink-200 backdrop-blur-sm p-4 rounded-3xl w-[28vw] mt-[4vh]">
        <h1 className="text-2xl font-semibold text-center text-black">
          Üye Olun
        </h1>
        <form className="space-y-4 mb-[2vh]">
          <RegInput title="Kullanıcı Adı" id="name" type="text" placeHolder="Kullanıcı Adınızı Giriniz" />
          <RegInput title="Email" id="email" type="text" placeHolder="Emailinizi Giriniz" />
          <RegInput title="Şifre" id="password" type="password" placeHolder="Şifrenizi Giriniz" />
          <RegInput title="Şifre Tekrar" id="password" type="password" placeHolder="Şifrenizi Tekrar Giriniz" />

          <button
            type="submit"
            className="w-full bg-purple-800 text-white py-2 rounded-lg hover:bg-purple-900 transition-colors flex items-center justify-center gap-2"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                clipRule="evenodd"
              />
            </svg>
            Üye Ol
          </button>
        </form>
        <div className="text-center text-sm text-black">
          Üye misiniz?{" "}
          <Link href="/login" className="text-purple-800 font-semibold hover:underline">
            Giriş Yap
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
